@extends('adminlte::page')
@section('content')
<div class="container">
    <h2>Editar Envio</h2>

    <form action="{{ route('envios.update', $envio->id) }}" method="POST">
        @csrf
        @method('PUT')

        <!-- Editar Envio -->
        <div class="form-group">
            <label for="celular">Celular</label>
            <input type="text" class="form-control" id="celular" name="celular" value="{{ old('celular', $envio->celular) }}" required>
        </div>

        <div class="form-group">
            <label for="departamento">Departamento</label>
            <input type="text" class="form-control" id="departamento" name="departamento" value="{{ old('departamento', $envio->departamento) }}" required>
        </div>

        <div class="form-group">
            <label for="monto_de_pago">Monto de Pago</label>
            <input type="number" class="form-control" id="monto_de_pago" name="monto_de_pago" value="{{ old('monto_de_pago', $envio->monto_de_pago) }}" required>
        </div>

        <div class="form-group">
            <label for="descripcion">Descripción</label>
            <textarea class="form-control" id="descripcion" name="descripcion" required>{{ old('descripcion', $envio->descripcion) }}</textarea>
        </div>

        <div class="form-group">
            <label for="estado">Estado</label>
            <select class="form-control" id="estado" name="estado" required>
                <option value="pendiente" {{ $envio->estado == 'pendiente' ? 'selected' : '' }}>Pendiente</option>
                <option value="confirmado" {{ $envio->estado == 'confirmado' ? 'selected' : '' }}>Confirmado</option>
            </select>
        </div>

        <!-- Editar Pedido (si es necesario) -->
        <h3>Editar Pedido Relacionado</h3>
        <div class="form-group">
            <label for="pedido_estado">Estado del Pedido</label>
            <select class="form-control" id="pedido_estado" name="pedido_estado" required>
                <option value="pendiente" {{ $envio->pedido->estado == 'pendiente' ? 'selected' : '' }}>Pendiente</option>
                <option value="confirmado" {{ $envio->pedido->estado == 'confirmado' ? 'selected' : '' }}>Confirmado</option>
            </select>
        </div>

        <!-- Editar Producto (relacionado con Envio) -->
        <h3>Editar Producto Relacionado</h3>
        <div class="form-group">
            <label for="producto_id">Producto</label>
            <select class="form-control" id="producto_id" name="producto_id" required>
                @foreach($productos as $producto)
                    <option value="{{ $producto->id }}" 
                        {{ $envio->pedido->pedidoProductos->first()->producto->id == $producto->id ? 'selected' : '' }}>
                        {{ $producto->nombre }}
                    </option>
                @endforeach
            </select>
        </div>

        <!-- Botón de Actualizar -->
        <button type="submit" class="btn btn-primary">Actualizar Envio y Pedido</button>
    </form>
</div>
@endsection
